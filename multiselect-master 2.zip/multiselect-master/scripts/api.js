const elem = document.getElementById('testSelect1');
const elem1 = document.querySelector("#testSelect1");
const Region = document.getElementById('testSelect1')
console.log(elem)
